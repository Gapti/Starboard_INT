These are the Dialoguer Examples. You can delete this folder if you wish. Though it is recommended that you create your own themes, feel free to use any of these dialogue themes in your final project!

To use any of these themes, go into their corresponding folder and find the prefabt. Drag the prefab into your scene, call Dialoguer.StartDialogue(i) and you're ready to go!